# PAC1 - M2.958 - Anàlisi de dades en entorns Big Data
BigData. Batch, HDFS i RDDs

__Activitat BATCH¶
Sistema de fitxers HDFS i extracció de coneixement de fonts de dades heterogènies mitjançant RDDs__


## Data:
octubre de 2025

## Autors:
* Raúl Esteban Redondo  
* Carles Dalmases Llordés
